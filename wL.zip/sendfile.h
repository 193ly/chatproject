#ifndef SENDFILE_H
#define SENDFILE_H

#include <QWidget>
#include<QMessageBox>
namespace Ui {
class SendFile;
}

class SendFile : public QWidget
{
    Q_OBJECT

public:
    explicit SendFile(QWidget *parent = 0);
    ~SendFile();
    void SetSendWindow(int);
    void set(bool f);
private slots:
    void on_pb_send_clicked();
    void on_pb_clear_clicked();

signals:
    void SIG_sendFile(FILE*,QString,int);

private:
    Ui::SendFile *ui;
    int m_friendId;
    bool canSend;
    char buf[1024];
};

#endif // SENDFILE_H
