#ifndef CHATDIALOG_H
#define CHATDIALOG_H

#include <QWidget>
#include"sendfile.h"
namespace Ui {
class ChatDialog;
}

class ChatDialog : public QWidget
{
    Q_OBJECT

public:
    explicit ChatDialog(QWidget *parent = 0);
    ~ChatDialog();
    //设置窗口属性
    void SetChatWindow(QString ip,int id = 0);

    //设置到聊天窗口上
    void SetChatContent(QString content);
    //设置群聊id
    void SetGroupId(int id);
    //设置群聊的内容的函数
    void SetTcpGroupChatContent(QString content,int friendIp);
    SendFile* ShowSendFile();

private slots:
    void on_pb_send_clicked();
    void on_pb_tool1_clicked();

signals:
    void SIG_SendContent(QString content,QString ip);
    void SIG_SendTcpContent(QString content,int id);
    void SIG_SendTcpGroupContent(QString content,int id);
private:
    Ui::ChatDialog *ui;
    SendFile* m_pSendFile;
    QString m_ip;
    int m_id;
    int groupid;
};

#endif // CHATDIALOG_H
