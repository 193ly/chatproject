#include "chatdialog.h"
#include "ui_chatdialog.h"
#include<QTime>
ChatDialog::ChatDialog(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ChatDialog),m_id(-1),groupid(-1)
{
    ui->setupUi(this);
    m_pSendFile = new SendFile;
}

ChatDialog::~ChatDialog()
{
    delete ui;
}

void ChatDialog::SetChatWindow(QString ip,int id)
{
    m_ip = ip;
    m_id = id;
    setWindowTitle(QString("[%1]").arg(m_ip));
    m_pSendFile->SetSendWindow(m_id);

}

void ChatDialog::SetChatContent(QString content)
{
        ui->tb_chat->append(QString("[%1] %2").arg(m_ip).arg(QTime::currentTime().toString("hh:mm:ss")));
        ui->tb_chat->append(content);
}

void ChatDialog::SetGroupId(int id)
{
    groupid = id;
}

void ChatDialog::SetTcpGroupChatContent(QString content,int friendId)
{
    ui->tb_chat->append(QString("[%1] %2").arg(friendId).arg(QTime::currentTime().toString("hh:mm:ss")));
    ui->tb_chat->append(content);
}

SendFile *ChatDialog::ShowSendFile()
{
    return m_pSendFile;
}



void ChatDialog::on_pb_send_clicked()
{
    //获取纯文本
    QString content = ui->te_chat->toPlainText();
    //判断输入是否全空格或空
    if(content.isEmpty() || content.remove(" ").isEmpty())
    {
        ui->te_chat->clear();
        return;
    }
    //获取带格式的文本
    content = ui->te_chat->toPlainText();
    //把编辑窗口清空
    ui->te_chat->clear();
    //显示到浏览窗口上
    ui->tb_chat->append(QString("[me] %1").arg(QTime::currentTime().toString("hh:mm:ss")));
    ui->tb_chat->append(content);
    //发送聊天内容到kernel，
    if(groupid >= 0)
    {
        Q_EMIT SIG_SendTcpGroupContent(content,groupid);
    }
    else if(m_id <= 0)
    {
        Q_EMIT SIG_SendContent(content,m_ip);
    }
    else
    {
        Q_EMIT SIG_SendTcpContent(content,m_id);
    }
}

void ChatDialog::on_pb_tool1_clicked()
{
    m_pSendFile->show();
}
