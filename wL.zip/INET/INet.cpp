#include "INet.h"

INet::INet()
{
}

INet::~INet()
{
}
