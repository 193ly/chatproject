#include"MidTcpNetClient.h"
#include"../INET/TcpNetClient.h"

MidTcpNetClient::MidTcpNetClient()
{
	m_INet = new TcpNetClient(this);
}

MidTcpNetClient::~MidTcpNetClient()
{
	if (m_INet)
	{
		delete m_INet;
		m_INet = nullptr;
	}
}

bool MidTcpNetClient::InitNet()
{
	return 0;
}

bool MidTcpNetClient::OpenNet()
{
	return m_INet->InitNet();

}

bool MidTcpNetClient::SendData(long ISend, char* sendBuf, int nLen)
{

    return m_INet->SendData(ISend, sendBuf, nLen);
}
//处理数据
void MidTcpNetClient::DealData(long ISend, char* sendBuf, int nLen)
{
    //cout << "MidTcpNetClient::DealData 开始处理数据：" << sendBuf << endl;
    Q_EMIT SIG_ReadyDate(ISend,sendBuf,nLen);
}

void MidTcpNetClient::UnInitNet()
{
	m_INet->UnInitNet(); 
}
