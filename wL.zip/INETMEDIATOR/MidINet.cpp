#pragma once
#include"MidINet.h"

MidINet::MidINet()
{
}

MidINet::~MidINet()
{
}

bool MidINet::InitNet()
{
	return false;
}
