#include "sendfile.h"
#include "ui_sendfile.h"

SendFile::SendFile(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::SendFile),canSend(false)
{
    ui->setupUi(this);
    m_friendId = 0;
}

SendFile::~SendFile()
{
    delete ui;
}

void SendFile::SetSendWindow(int id)
{
    m_friendId = id;
}

void SendFile::set(bool f)
{
    canSend = f;
}

void SendFile::on_pb_send_clicked()
{
   QString sendStr = this->ui->textEdit->toPlainText();
   //判断输入是否全空格或空
   if(sendStr.isEmpty() || sendStr.remove(" ").isEmpty())
   {
      QMessageBox::about(this,"error","不能为空");
      ui->textEdit->clear();
      return;
   }
   //获取带格式的文本
   //sendStr = ui->textEdit->toPlainText();
   sendStr.replace("\\20052","");
   //‪D:\bmd.txt
   sendStr.replace("\\","/");
   int len = sendStr.length();
   for(int i = 0;i<len;i++)
   {

       if(sendStr[i] == 'D' || sendStr[i] == 'E' || sendStr[i] == 'F' || sendStr[i] == 'C')
       {
            int n = 0;
            n = len - i;
            for(int j = 0;j<=n;j++,i++)
            {
                sendStr[j] = sendStr[i];
            }
            break;
       }
   }
   sendStr.remove(" ");
   sendStr.remove("");
   len = sendStr.length();
   int pos1= 0;
   for(int i =0; i<len;i++)
   {
        if(sendStr[i] == '/')
        {
            pos1 = i;
        }

   }
   QString name = "";
   int i= 0;
   while(len - pos1 >= 0)
   {
       name[i] = sendStr[pos1];
       i++;
       pos1++;
   }
   FILE* from = fopen(sendStr.toStdString().c_str(), "rb");
   Q_EMIT SIG_sendFile(from,name,m_friendId);
}

void SendFile::on_pb_clear_clicked()
{
    ui->textEdit->clear();
}
